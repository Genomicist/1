library(testthat)
library(RoaRyVis)

test_check("RoaRyVis")
